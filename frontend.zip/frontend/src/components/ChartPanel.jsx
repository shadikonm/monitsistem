import { useMemo } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid
} from 'recharts';
import { formatTime } from '../utils/formatters';

export function ChartPanel({ history, quote, base, sourceKind }) {
  const points = useMemo(
    () =>
      history.map((item) => ({
        time: formatTime(item.ts),
        rate: Number(item.rate)
      })),
    [history]
  );

  const minRate = useMemo(() => {
    if (!points.length) return 0;
    return Math.min(...points.map(p => p.rate));
  }, [points]);
  
  const maxRate = useMemo(() => {
    if (!points.length) return 0;
    return Math.max(...points.map(p => p.rate));
  }, [points]);

  if (!points.length) {
    return (
      <div className="h-[320px] w-full mt-4 flex items-center justify-center text-on-surface-variant font-label text-sm border border-outline-variant/10 border-dashed rounded-xl">
        Ожидание данных графика...
      </div>
    );
  }

  // Adjust domain for a bit of padding
  const padding = (maxRate - minRate) * 0.05 || maxRate * 0.001;

  return (
    <div className="h-[320px] w-full mt-4">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={points}>
          <defs>
            <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#a6c8ff" stopOpacity={0.3}/>
              <stop offset="100%" stopColor="#a6c8ff" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(140, 144, 162, 0.1)" />
          <XAxis
            dataKey="time"
            minTickGap={30}
            stroke="#8c90a2"
            tick={{ fill: '#8c90a2', fontSize: 11 }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            domain={[minRate - padding, maxRate + padding]}
            stroke="#8c90a2"
            tick={{ fill: '#8c90a2', fontSize: 11 }}
            tickFormatter={(v) => v.toFixed(4)}
            axisLine={false}
            tickLine={false}
            orientation="right"
          />
          <Tooltip
            contentStyle={{
              background: 'rgba(30, 32, 36, 0.95)',
              border: '1px solid rgba(140, 144, 162, 0.2)',
              borderRadius: '8px',
              color: '#e2e2e8',
              boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.5)'
            }}
            itemStyle={{ color: '#a6c8ff' }}
          />
          <Area
            type="monotone"
            dataKey="rate"
            stroke="#a6c8ff"
            strokeWidth={2}
            fill="url(#chartGradient)"
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
