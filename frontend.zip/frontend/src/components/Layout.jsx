import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { AssistantWidget } from './AssistantWidget';

export function Layout() {
  const location = useLocation();

  const navItems = [
    { name: 'Рынки', path: '/', icon: 'show_chart', filledIcon: 'show_chart' },
    { name: 'Обмен', path: '/exchange', icon: 'swap_horiz', filledIcon: 'swap_horiz' },
    { name: 'Уведомления', path: '/alerts', icon: 'notifications_active', filledIcon: 'notifications_active' }
  ];

  const getPageTitle = () => {
    switch (location.pathname) {
      case '/': return 'Sovereign Ledger';
      case '/exchange': return 'Обмен';
      case '/alerts': return 'Sovereign Ledger';
      default: return 'Sovereign Ledger';
    }
  };

  return (
    <div className="flex h-screen w-full bg-surface text-on-surface font-body overflow-hidden selection:bg-primary-container selection:text-on-primary-container">
      
      {/* Desktop SideNavBar */}
      <aside className="hidden md:flex flex-col h-full py-8 px-4 w-64 bg-[#0c0e12] font-['Manrope'] text-sm font-medium border-r border-outline-variant/10">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="w-10 h-10 rounded hero-gradient flex items-center justify-center">
            <span className="material-symbols-outlined text-on-primary-container" style={{ fontVariationSettings: "'FILL' 1" }}>account_balance_wallet</span>
          </div>
          <div>
            <h1 className="text-lg font-black text-[#e2e2e8] leading-tight">Sovereign</h1>
            <p className="text-[10px] uppercase tracking-widest text-on-surface-variant/60">Аналитика Ledger</p>
          </div>
        </div>

        <nav className="flex-1 space-y-2">
          {navItems.map(item => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => 
                `flex items-center gap-3 px-4 py-3 rounded-lg transition-all group ` +
                (isActive 
                  ? `text-[#0061FF] bg-[#1e2024] scale-[0.98]` 
                  : `text-[#e2e2e8]/50 hover:bg-[#1e2024] hover:text-[#e2e2e8]`)
              }
            >
              {({ isActive }) => (
                <>
                  <span 
                    className="material-symbols-outlined" 
                    style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}
                  >
                    {isActive ? item.filledIcon : item.icon}
                  </span>
                  <span className={isActive ? "font-bold" : ""}>{item.name}</span>
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="mt-auto space-y-2 pt-6">
          <button className="w-full hero-gradient text-on-primary-container font-bold py-3 rounded-lg mb-4 text-xs uppercase tracking-widest active:scale-[0.98] transition-transform">
            Торговать
          </button>
          <a className="flex items-center gap-3 px-4 py-3 text-[#e2e2e8]/50 hover:bg-[#1e2024] transition-all rounded-lg" href="#">
            <span className="material-symbols-outlined text-sm" style={{ fontVariationSettings: "'FILL' 0" }}>help</span>
            <span>Поддержка</span>
          </a>
          <a className="flex items-center gap-3 px-4 py-3 text-[#e2e2e8]/50 hover:bg-[#1e2024] transition-all rounded-lg" href="#">
            <span className="material-symbols-outlined text-sm" style={{ fontVariationSettings: "'FILL' 0" }}>logout</span>
            <span>Выйти</span>
          </a>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#111317]">
        
        {/* TopNavBar */}
        <header className="flex justify-between items-center w-full px-8 h-16 bg-[#111317] font-['Manrope'] tracking-tight border-b border-outline-variant/10 z-10">
          <div className="flex items-center gap-8">
            <span className="text-xl font-bold text-[#e2e2e8] tracking-widest uppercase md:hidden">{getPageTitle()}</span>
            <span className="text-xl font-bold text-[#e2e2e8] tracking-widest uppercase hidden md:inline-block">
              {location.pathname === '/exchange' ? 'Обмен' : 'Sovereign Ledger'}
            </span>
            
            <nav className="hidden lg:flex items-center gap-6 ml-8">
              {navItems.map(item => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({isActive}) => isActive 
                    ? "text-[#0061FF] font-bold border-b-2 border-[#0061FF] py-5 flex items-center gap-2" 
                    : "text-[#e2e2e8]/60 hover:text-[#e2e2e8] transition-colors duration-200 py-5 flex items-center gap-2"}
                >
                  {({ isActive }) => (
                    <>
                      <span className="material-symbols-outlined text-sm" style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}>
                        {isActive ? item.filledIcon : item.icon}
                      </span>
                      {item.name}
                    </>
                  )}
                </NavLink>
              ))}
            </nav>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="relative hidden sm:block">
              <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-sm border-none">search</span>
              <input 
                className="bg-surface-container-lowest border-none rounded-lg pl-10 pr-4 py-2 text-sm w-64 focus:ring-1 focus:ring-primary/40 text-on-surface outline-none placeholder-on-surface-variant/40" 
                placeholder="Поиск..." 
                type="text"
              />
            </div>
            <div className="flex items-center gap-4">
              <button className="text-[#e2e2e8]/60 hover:text-[#e2e2e8] transition-colors relative">
                <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 0" }}>notifications</span>
                <span className="absolute top-0 right-0 w-2 h-2 bg-[#0061FF] rounded-full"></span>
              </button>
              <button className="text-[#e2e2e8]/60 hover:text-[#e2e2e8] transition-colors">
                <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 0" }}>settings</span>
              </button>
              <div className="w-8 h-8 rounded-full overflow-hidden border border-outline-variant/30 flex items-center justify-center bg-surface-container-highest cursor-pointer hover:scale-105 transition-transform">
                 <span className="text-sm font-bold text-on-surface">U</span>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-x-hidden overflow-y-auto no-scrollbar relative w-full styled-scroll">
          <Outlet />
        </main>
      </div>

      {/* Mobile Bottom NavBar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-[#0c0e12] flex items-center justify-around px-4 border-t border-outline-variant/10 z-50">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => 
              `flex flex-col items-center gap-1 ${isActive ? 'text-[#0061FF]' : 'text-[#e2e2e8]/50'}`
            }
          >
            {({ isActive }) => (
              <>
                <span className="material-symbols-outlined" style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}>
                  {isActive ? item.filledIcon : item.icon}
                </span>
                <span className={`text-[10px] ${isActive ? 'font-bold' : 'font-medium'}`}>{item.name}</span>
              </>
            )}
          </NavLink>
        ))}
        <button className="flex flex-col items-center gap-1 text-[#e2e2e8]/50">
          <span className="material-symbols-outlined">person</span>
          <span className="text-[10px] font-medium">Профиль</span>
        </button>
      </nav>

      {/* Persistent AI Assistant */}
      <AssistantWidget />
    </div>
  );
}
