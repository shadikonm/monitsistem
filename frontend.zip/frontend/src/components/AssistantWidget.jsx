import { useState } from 'react';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000';

export function AssistantWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([
    { role: 'assistant', text: 'Я могу помочь с текущими курсами и уведомлениями. Спрашивайте что угодно.' }
  ]);

  async function send() {
    const text = input.trim();
    if (!text) return;

    setMessages((prev) => [...prev, { role: 'user', text }]);
    setInput('');

    try {
      const response = await fetch(`${API_BASE}/api/assistant`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text })
      });
      const data = await response.json();
      setMessages((prev) => [...prev, { role: 'assistant', text: data.reply || 'Нет ответа' }]);
    } catch {
      setMessages((prev) => [...prev, { role: 'assistant', text: 'Ошибка подключения к ассистенту.' }]);
    }
  }

  return (
    <div className="fixed right-6 bottom-6 z-50">
      {open && (
        <div className="w-[340px] h-[450px] rounded-xl bg-surface-container border border-outline-variant/20 shadow-2xl mb-3 flex flex-col overflow-hidden">
          <div className="bg-primary px-4 py-3 text-on-primary font-semibold flex items-center gap-2">
            <span className="material-symbols-outlined text-lg" style={{ fontVariationSettings: "'FILL' 1" }}>smart_toy</span>
            ИИ Ассистент
          </div>
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`px-3 py-2 rounded-lg text-sm ${
                  m.role === 'user'
                    ? 'bg-primary/20 text-on-surface self-end'
                    : 'bg-surface-container-high text-on-surface-variant self-start'
                }`}
              >
                {m.text}
              </div>
            ))}
          </div>
          <div className="border-t border-outline-variant/20 p-3 flex gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Спросить о курсах..."
              onKeyDown={(e) => e.key === 'Enter' && send()}
              className="flex-1 bg-surface-container-lowest border-none rounded-lg px-3 py-2 text-sm text-on-surface placeholder:text-on-surface-variant/50 focus:ring-1 focus:ring-primary/50 outline-none"
            />
            <button
              onClick={send}
              className="hero-gradient text-on-primary-container px-4 py-2 rounded-lg text-sm font-semibold"
            >
              Отправить
            </button>
          </div>
        </div>
      )}
      <button
        onClick={() => setOpen((v) => !v)}
        className="w-14 h-14 rounded-full hero-gradient shadow-xl flex items-center justify-center text-on-primary-container hover:scale-105 transition-transform"
      >
        <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 1" }}>
          {open ? 'close' : 'smart_toy'}
        </span>
      </button>
    </div>
  );
}
