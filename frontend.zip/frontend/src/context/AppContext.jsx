import { createContext, useContext, useState, useEffect, useRef } from 'react';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000';

const AppContext = createContext();

export function AppProvider({ children }) {
  const [config, setConfig] = useState({
    base: 'USD',
    quotes: [],
    thresholdPercent: 2,
    source: { provider: '', official: false, referenceDate: null }
  });
  const [latestRates, setLatestRates] = useState([]);
  const [selectedQuote, setSelectedQuote] = useState('EUR');
  const [history, setHistory] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [timeRange, setTimeRange] = useState('24H');

  const prevRatesRef = useRef({});

  async function loadConfig() {
    try {
      const response = await fetch(`${API_BASE}/api/config`);
      const data = await response.json();
      setConfig(data);
      if (data.quotes?.length && !selectedQuote) {
        setSelectedQuote(data.quotes[0]);
      }
    } catch (e) {
      console.error(e);
    }
  }

  async function loadLatest() {
    try {
      const response = await fetch(`${API_BASE}/api/rates/latest`);
      const data = await response.json();
      setLatestRates(data);
    } catch (e) {
      console.error(e);
    }
  }

  async function loadHistory(quote) {
    try {
      const hours = timeRange === '1H' ? 1 : timeRange === '7D' ? 168 : timeRange === '30D' ? 720 : 24;
      const response = await fetch(`${API_BASE}/api/rates/history/${quote}?hours=${hours}`);
      const data = await response.json();
      setHistory(data);
    } catch (e) {
      console.error(e);
    }
  }

  async function loadAlerts() {
    try {
      const response = await fetch(`${API_BASE}/api/alerts`);
      const data = await response.json();
      setAlerts(data);
    } catch (e) {
      console.error(e);
    }
  }

  useEffect(() => {
    loadConfig();
    loadLatest();
    loadAlerts();
  }, []);

  useEffect(() => {
    if (!selectedQuote) return;
    loadHistory(selectedQuote);
  }, [selectedQuote, timeRange]);

  useEffect(() => {
    const alertsStream = new EventSource(`${API_BASE}/api/alerts/stream`);
    alertsStream.onmessage = (event) => {
      try {
        const alert = JSON.parse(event.data);
        setAlerts((prev) => [alert, ...prev].slice(0, 50));
      } catch {}
    };

    const ratesStream = new EventSource(`${API_BASE}/api/rates/stream`);
    ratesStream.onmessage = (event) => {
      try {
        const rows = JSON.parse(event.data);
        if (!Array.isArray(rows)) return;

        // Calculate change percentage
        const newRates = rows.map(r => {
          const prev = prevRatesRef.current[r.quote_currency];
          const changePercent = prev ? ((r.rate - prev.rate) / prev.rate) * 100 : 0;
          return { ...r, changePercent };
        });

        // Update ref for next comparison
        rows.forEach(r => {
          prevRatesRef.current[r.quote_currency] = r;
        });

        setLatestRates(newRates);
        const selected = newRates.find((r) => r.quote_currency === selectedQuote);
        if (!selected) return;

        setHistory((prev) => {
          if (!prev.length) return [{ ts: selected.ts, rate: selected.rate }];
          const last = prev[prev.length - 1];
          // avoid duplicate timestamps in history graph visually
          if (last.ts === selected.ts) return prev;
          return [...prev, { ts: selected.ts, rate: selected.rate }].slice(-100);
        });
      } catch {}
    };

    return () => {
      alertsStream.close();
      ratesStream.close();
    };
  }, [selectedQuote]);

  const value = {
    config,
    latestRates,
    selectedQuote,
    setSelectedQuote,
    history,
    alerts,
    timeRange,
    setTimeRange
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppContext() {
  return useContext(AppContext);
}
