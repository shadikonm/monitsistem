export const currencyFlags = {
  EUR: '🇪🇺',
  GBP: '🇬🇧',
  JPY: '🇯🇵',
  CAD: '🇨🇦',
  AUD: '🇦🇺',
  CHF: '🇨🇭',
  CNY: '🇨🇳',
  RUB: '🇷🇺',
  KZT: '🇰🇿',
  KGS: '🇰🇬',
  USDT: '💰',
  BTC: '₿',
  ETH: 'Ξ',
  BNB: '🔶',
  USD: '🇺🇸'
};

export function formatTime(ts) {
  return new Date(ts).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

export function formatDateTime(ts) {
  return new Date(ts).toLocaleString('en-US', {
    month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
  });
}

export function formatPair(base, quote, sourceKind) {
  if (sourceKind === 'binance_crypto') {
    return `${quote}/${base}`;
  }
  return `${base}/${quote}`;
}
