import { useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { ChartPanel } from '../components/ChartPanel';
import { currencyFlags, formatPair, formatDateTime } from '../utils/formatters';

export function Dashboard() {
  const {
    config,
    latestRates,
    selectedQuote,
    setSelectedQuote,
    history,
    alerts,
    timeRange,
    setTimeRange
  } = useAppContext();

  const selectedRate = latestRates.find(r => r.quote_currency === selectedQuote);
  const latestHistory = history.length ? history[history.length - 1] : null;
  const displayRate = selectedRate || latestHistory;

  const high24h = useMemo(() => {
    if (!history.length) return null;
    return Math.max(...history.map(h => Number(h.rate)));
  }, [history]);

  const low24h = useMemo(() => {
    if (!history.length) return null;
    return Math.min(...history.map(h => Number(h.rate)));
  }, [history]);

  return (
    <div className="max-w-[1500px] mx-auto p-8 grid-pattern animate-in fade-in duration-500">
      <div className="flex flex-col lg:flex-row gap-8">
        
        {/* Main Content (70%) */}
        <div className="flex-1 lg:w-[70%] flex flex-col gap-8">
          
          {/* Hero Currency Card */}
          <section className="glass-panel rounded-xl p-8 border border-outline-variant/10 shadow-lg shadow-black/50">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
              <div>
                <div className="flex items-center gap-3 mb-1">
                  <div className="w-8 h-8 rounded-full bg-surface-container-highest flex items-center justify-center text-lg">
                    {currencyFlags[selectedQuote] || '💱'}
                  </div>
                  <h1 className="text-2xl font-headline font-bold text-on-surface">
                    {formatPair(config.base, selectedQuote, config.source?.kind)}
                  </h1>
                  {displayRate && (
                    <span className={`px-2 py-0.5 text-xs font-bold rounded-full ${
                      (displayRate.changePercent || 0) >= 0
                        ? 'bg-tertiary/10 text-tertiary'
                        : 'bg-error/10 text-error'
                    }`}>
                      {(displayRate.changePercent || 0) >= 0 ? '+' : ''}{(displayRate.changePercent || 0).toFixed(2)}%
                    </span>
                  )}
                </div>
                <p className="text-on-surface-variant text-sm font-label uppercase tracking-widest">
                  Текущий курс {selectedQuote} / {config.base}
                </p>
              </div>
              <div className="flex bg-surface-container-lowest p-1 rounded-lg">
                {['1H', '24H', '7D', '30D'].map((range) => (
                  <button
                    key={range}
                    onClick={() => setTimeRange(range)}
                    className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all ${
                      timeRange === range
                        ? 'bg-surface-container-high text-primary shadow-sm'
                        : 'text-on-surface-variant hover:text-on-surface'
                    }`}
                  >
                    {range.replace('H', 'Ч').replace('D', 'Д')}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-baseline gap-4 mb-6">
              <span className="text-6xl font-headline font-extrabold tracking-tight text-on-surface">
                {displayRate ? Number(displayRate.rate).toFixed(4) : '—'}
              </span>
              <span className="text-xl text-on-surface-variant font-medium">{selectedQuote}</span>
            </div>

            <ChartPanel
              history={history}
              quote={selectedQuote}
              base={config.base}
              sourceKind={config.source?.kind}
            />
          </section>

          {/* Market Details Bento Section */}
          <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-surface-container-low p-6 rounded-xl border border-outline-variant/10 hover:border-outline-variant/30 transition-colors">
              <p className="text-on-surface-variant text-xs uppercase tracking-widest font-bold mb-2">Макс. за 24ч</p>
              <p className="text-xl font-headline font-bold text-on-surface">
                {high24h ? high24h.toFixed(4) : '—'} <span className="text-sm font-normal text-on-surface-variant">{selectedQuote}</span>
              </p>
            </div>
            <div className="bg-surface-container-low p-6 rounded-xl border border-outline-variant/10 hover:border-outline-variant/30 transition-colors">
              <p className="text-on-surface-variant text-xs uppercase tracking-widest font-bold mb-2">Мин. за 24ч</p>
              <p className="text-xl font-headline font-bold text-on-surface">
                {low24h ? low24h.toFixed(4) : '—'} <span className="text-sm font-normal text-on-surface-variant">{selectedQuote}</span>
              </p>
            </div>
            <div className="bg-surface-container-low p-6 rounded-xl border border-outline-variant/10 hover:border-outline-variant/30 transition-colors">
              <p className="text-on-surface-variant text-xs uppercase tracking-widest font-bold mb-2">Порог алерта</p>
              <p className="text-xl font-headline font-bold text-on-surface">
                {config.thresholdPercent}% <span className="text-sm font-normal text-on-surface-variant">изм.</span>
              </p>
            </div>
          </section>
        </div>

        {/* Sidebar (30%) */}
        <aside className="w-full lg:w-[30%] flex flex-col gap-8">
          
          {/* Exchange Rates List */}
          <div className="bg-surface-container p-6 rounded-xl border border-outline-variant/10 shadow-lg shadow-black/50">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-headline font-bold text-lg text-on-surface">Курсы валют</h2>
              <span className="material-symbols-outlined text-outline cursor-pointer hover:text-on-surface transition-colors" style={{ fontVariationSettings: "'FILL' 0" }}>more_horiz</span>
            </div>
            <div className="space-y-1 max-h-[350px] overflow-y-auto no-scrollbar styled-scroll pr-2">
              {latestRates.map((item) => (
                <div
                  key={item.quote_currency}
                  onClick={() => setSelectedQuote(item.quote_currency)}
                  className={`group flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors duration-200 ${
                    selectedQuote === item.quote_currency
                      ? 'bg-primary/10 border border-primary/20'
                      : 'hover:bg-surface-container-high border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-surface-container-highest flex items-center justify-center text-sm shadow-inner">
                      {currencyFlags[item.quote_currency] || '💱'}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-on-surface">{formatPair(config.base, item.quote_currency, config.source?.kind)}</p>
                      <p className="text-[10px] text-on-surface-variant font-label uppercase tracking-tighter">{item.quote_currency}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-on-surface">{Number(item.rate).toFixed(4)}</p>
                    <p className={`text-[10px] font-bold ${
                      (item.changePercent || 0) >= 0 ? 'text-tertiary' : 'text-error'
                    }`}>
                      {(item.changePercent || 0) >= 0 ? '+' : ''}{(item.changePercent || 0).toFixed(2)}%
                    </p>
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full mt-6 py-3 rounded-lg bg-surface-container-highest text-on-surface text-xs font-bold uppercase tracking-widest hover:bg-surface-variant transition-colors border border-outline-variant/10">
              Смотреть все рынки
            </button>
          </div>

          {/* Intelligence Snippet */}
          <div className="bg-surface-container-lowest p-6 rounded-xl border border-outline-variant/10 border-dashed">
            <h4 className="text-[10px] font-bold text-on-surface-variant uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-tertiary animate-pulse"></span>
              Актуальная аналитика
            </h4>
            <div className="space-y-4">
              <div className="flex gap-3">
                <div className="w-1 rounded-full bg-tertiary/50"></div>
                <p className="text-xs leading-relaxed text-on-surface-variant">
                  Сетевая задержка: <span className="text-on-surface font-medium">12мс</span>. Моментальное выполнение.
                </p>
              </div>
              <div className="flex gap-3">
                <div className="w-1 rounded-full bg-primary/50"></div>
                <p className="text-xs leading-relaxed text-on-surface-variant">
                  Источник данных: <span className="text-on-surface font-medium capitalize">{config.source?.provider || 'Загрузка'}</span>
                </p>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
