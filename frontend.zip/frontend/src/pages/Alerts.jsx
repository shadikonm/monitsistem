import { useAppContext } from '../context/AppContext';
import { formatDateTime } from '../utils/formatters';

export function Alerts() {
  const { alerts, latestRates } = useAppContext();

  // Mock data
  const activeMonitors = [
    { pair: 'BTC / USD', direction: 'Выше', threshold: '$69,200.00', current: '$67,842.12', status: 'Активен', icon: 'currency_bitcoin' },
    { pair: 'EUR / USD', direction: 'Ниже', threshold: '1.08500', current: '1.09214', status: 'Пауза', icon: 'euro' },
    { pair: 'ETH / BTC', direction: 'Выше', threshold: '0.0520', current: '0.0518', status: 'Активен', icon: 'token' }
  ];

  return (
    <div className="max-w-[1400px] mx-auto p-8 animate-in fade-in duration-500">
      <div className="mb-12">
        <h2 className="text-4xl font-extrabold font-headline tracking-tighter text-on-surface mb-2">Система Уведомлений</h2>
        <p className="text-on-surface-variant max-w-2xl font-light text-sm">
          Настройка высокоточных триггеров для вашего портфеля. Мониторинг институциональных пулов ликвидности в реальном времени.
        </p>
      </div>

      <div className="grid grid-cols-12 gap-8">
        {/* Create Alert Section */}
        <section className="col-span-12 lg:col-span-4 space-y-6">
          <div className="bg-surface-container-low p-6 rounded-xl border border-outline-variant/15 relative overflow-hidden group shadow-lg">
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-primary/5 rounded-full blur-3xl group-hover:bg-primary/10 transition-colors"></div>
            <h3 className="text-lg font-bold font-headline mb-6 flex items-center gap-2 text-on-surface">
              <span className="material-symbols-outlined text-primary" style={{ fontVariationSettings: "'FILL' 1" }}>add_circle</span>
              Создать Новый Алерт
            </h3>
            
            <form className="space-y-5 relative z-10" onSubmit={e => e.preventDefault()}>
              <div className="space-y-1.5">
                <label className="text-[10px] uppercase tracking-widest font-bold text-on-surface-variant">Валютная пара</label>
                <div className="bg-surface-container-lowest p-3 rounded-lg flex items-center justify-between border border-outline-variant/20 hover:border-outline-variant/40 cursor-pointer">
                  <span className="font-medium text-on-surface text-sm">BTC / USD</span>
                  <span className="material-symbols-outlined text-on-surface-variant text-sm">expand_more</span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase tracking-widest font-bold text-on-surface-variant">Условие</label>
                  <select className="w-full bg-surface-container-lowest border border-outline-variant/20 text-on-surface text-sm p-3 rounded-lg focus:ring-1 focus:ring-primary/40 focus:outline-none appearance-none cursor-pointer">
                    <option>Цена выше</option>
                    <option>Цена ниже</option>
                    <option>Пересечение скользящих</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase tracking-widest font-bold text-on-surface-variant">Значение</label>
                  <input className="w-full bg-surface-container-lowest border border-outline-variant/20 text-on-surface text-sm p-3 rounded-lg focus:ring-1 focus:ring-primary/40 focus:outline-none placeholder-on-surface-variant/30" placeholder="68,500.00" type="text" />
                </div>
              </div>
              
              <div className="space-y-1.5">
                <label className="text-[10px] uppercase tracking-widest font-bold text-on-surface-variant">Доставка</label>
                <div className="flex gap-2">
                  <button className="flex-1 py-2 bg-primary/10 text-primary border border-primary/20 rounded-md text-xs font-bold shadow-sm" type="button">Push</button>
                  <button className="flex-1 py-2 bg-surface-container-lowest text-on-surface-variant border border-transparent hover:border-outline-variant/20 rounded-md text-xs font-medium transition-colors" type="button">Email</button>
                  <button className="flex-1 py-2 bg-surface-container-lowest text-on-surface-variant border border-transparent hover:border-outline-variant/20 rounded-md text-xs font-medium transition-colors" type="button">Webhook</button>
                </div>
              </div>
              
              <button className="w-full py-4 hero-gradient text-on-primary-container font-bold rounded-lg shadow-lg shadow-primary/20 mt-6 active:scale-[0.98] transition-transform text-sm uppercase tracking-widest">
                Запустить Триггер
              </button>
            </form>
          </div>

          <div className="bg-surface-container p-5 rounded-xl border border-outline-variant/10 shadow-lg">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-tertiary/10 flex items-center justify-center text-tertiary">
                <span className="material-symbols-outlined">bolt</span>
              </div>
              <div>
                <h4 className="text-sm font-bold text-on-surface">Сетевая задержка</h4>
                <p className="text-[10px] text-on-surface-variant">Глоб. Синхронизация: 12мс</p>
              </div>
            </div>
            <p className="text-xs leading-relaxed text-on-surface-variant">
              Ваши уведомления обрабатываются в 4 географических регионах для обеспечения суб-секундного реагирования в условиях высокой волатильности.
            </p>
          </div>
        </section>

        {/* Active Alerts List */}
        <section className="col-span-12 lg:col-span-8 space-y-8">
          
          <div className="flex items-end justify-between border-b border-outline-variant/10 pb-4">
            <div>
              <h3 className="text-2xl font-bold font-headline tracking-tight text-on-surface">Активные Триггеры</h3>
              <p className="text-xs text-on-surface-variant mt-1">{activeMonitors.length} Активных Уведомлений</p>
            </div>
            <div className="hidden sm:flex gap-6 text-xs font-medium">
              <button className="text-primary border-b-2 border-primary pb-2 font-bold px-1">Все активы</button>
              <button className="text-on-surface-variant hover:text-on-surface transition-colors pb-2 px-1">Крипта</button>
              <button className="text-on-surface-variant hover:text-on-surface transition-colors pb-2 px-1">Фиат</button>
            </div>
          </div>

          <div className="space-y-4">
            {activeMonitors.map((monitor, idx) => (
              <div key={idx} className="bg-surface-container-low hover:bg-surface-container transition-colors duration-300 p-5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 group border border-transparent hover:border-outline-variant/10 shadow-sm">
                
                <div className="flex items-center gap-5">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                    monitor.status === 'Активен' 
                      ? 'bg-primary/10 text-primary group-hover:bg-primary/20' 
                      : 'bg-on-surface-variant/10 text-on-surface-variant group-hover:bg-on-surface-variant/20'
                  }`}>
                    <span className="material-symbols-outlined text-[24px]">{monitor.icon}</span>
                  </div>
                  <div>
                    <h4 className="font-bold tracking-tight text-on-surface text-[15px]">{monitor.pair}</h4>
                    <p className="text-xs text-on-surface-variant flex items-center gap-1.5 mt-0.5">
                      <span className="material-symbols-outlined text-[14px]">
                        {monitor.direction === 'Выше' ? 'trending_up' : 'trending_down'}
                      </span>
                      {monitor.direction} <span className="text-on-surface font-mono opacity-90">{monitor.threshold}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-8 ml-17 sm:ml-0">
                  <div className="text-left sm:text-right">
                    <p className="text-[9px] uppercase tracking-[0.1em] text-on-surface-variant font-bold mb-0.5">Текущий Курс</p>
                    <p className={`text-sm font-mono font-medium ${monitor.status === 'Активен' ? 'text-primary' : 'text-on-surface-variant'}`}>
                      {monitor.current}
                    </p>
                  </div>
                  
                  <div className="flex items-center gap-5">
                    <div className={`flex items-center gap-2 px-2.5 py-1 rounded-full border ${
                      monitor.status === 'Активен' 
                        ? 'bg-primary/10 border-primary/20' 
                        : 'bg-surface-container-highest border-transparent'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${monitor.status === 'Активен' ? 'bg-primary shadow-[0_0_8px_rgba(166,200,255,0.6)]' : 'bg-on-surface-variant/50'}`}></span>
                      <span className={`text-[9px] font-bold uppercase tracking-wider ${monitor.status === 'Активен' ? 'text-primary' : 'text-on-surface-variant'}`}>
                        {monitor.status}
                      </span>
                    </div>
                    
                    <button className="text-on-surface-variant hover:text-error transition-colors p-1" title="Удалить">
                      <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 0" }}>delete</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Triggered History */}
          <div className="mt-12 pt-4">
            <h3 className="text-lg font-bold font-headline mb-4 text-on-surface">Сработанные Уведомления</h3>
            <div className="bg-surface-container-lowest border border-outline-variant/10 rounded-xl overflow-hidden shadow-sm">
              <table className="w-full text-left text-sm">
                <thead className="bg-[#181a1f] text-[9px] uppercase tracking-[0.15em] text-on-surface-variant font-bold">
                  <tr>
                    <th className="p-4 py-3 font-medium">Событие</th>
                    <th className="p-4 py-3 font-medium hidden sm:table-cell">Системное Правило</th>
                    <th className="p-4 py-3 font-medium text-right sm:text-left">Время Срабатывания</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-outline-variant/5">
                  {alerts.length === 0 && (
                    <tr>
                      <td colSpan="3" className="p-6 text-center text-sm text-on-surface-variant font-medium">
                        События не найдены.
                      </td>
                    </tr>
                  )}
                  {alerts.map((alert, i) => (
                    <tr key={i} className="hover:bg-surface-container/40 transition-colors group">
                      <td className="p-4 flex items-center gap-3">
                        <div className={`w-1.5 h-1.5 rounded-full ${Number(alert.change_percent) > 0 ? 'bg-tertiary' : 'bg-error'}`}></div>
                        <span className="text-on-surface font-medium text-xs">{alert.message}</span>
                      </td>
                      <td className="p-4 text-xs text-on-surface-variant hidden sm:table-cell font-mono">
                         SYSTEM_RULE_{i}
                      </td>
                      <td className="p-4 text-[11px] text-on-surface-variant text-right sm:text-left whitespace-nowrap">
                        {formatDateTime(alert.ts)}
                      </td>
                    </tr>
                  ))}
                  {/* Fallback Mock Data */}
                  {alerts.length === 0 && (
                    <>
                      <tr className="hover:bg-surface-container/40 transition-colors">
                        <td className="p-4 flex items-center gap-3">
                          <div className="w-1.5 h-1.5 rounded-full bg-tertiary"></div>
                          <span className="text-on-surface font-medium text-xs text-bold">SOL / USD резко вырос до $145.00</span>
                        </td>
                        <td className="p-4 text-xs text-on-surface-variant hidden sm:table-cell font-mono">SYSTEM_RULE</td>
                        <td className="p-4 text-[11px] text-on-surface-variant text-right sm:text-left">24 Нояб, 14:22</td>
                      </tr>
                      <tr className="hover:bg-surface-container/40 transition-colors">
                        <td className="p-4 flex items-center gap-3">
                          <div className="w-1.5 h-1.5 rounded-full bg-error"></div>
                          <span className="text-on-surface font-medium text-xs text-bold">ЗОЛОТО упало ниже $1,980.00</span>
                        </td>
                        <td className="p-4 text-xs text-on-surface-variant hidden sm:table-cell font-mono">SYSTEM_RULE</td>
                        <td className="p-4 text-[11px] text-on-surface-variant text-right sm:text-left">22 Нояб, 09:15</td>
                      </tr>
                    </>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
