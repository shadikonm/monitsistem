import { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { currencyFlags, formatPair } from '../utils/formatters';

export function Exchange() {
  const { latestRates, selectedQuote } = useAppContext();
  const [fromAmount, setFromAmount] = useState('0.05');
  const [isSwapped, setIsSwapped] = useState(false);

  // Mock calculation logic for UI
  const btcRate = latestRates.find(r => r.quote_currency === 'BTC')?.rate || 63492.12; 
  const currentRate = isSwapped ? (1 / btcRate) : btcRate;
  
  const fromCurrency = isSwapped ? 'USDT' : 'BTC';
  const toCurrency = isSwapped ? 'BTC' : 'USDT';
  
  const estimatedTo = (Number(fromAmount || 0) * currentRate).toFixed(4);
  const fee = (Number(estimatedTo) * 0.001).toFixed(4); // 0.1% fee
  const total = (Number(estimatedTo) - Number(fee)).toFixed(4);

  return (
    <div className="max-w-[1500px] mx-auto p-8 grid-pattern animate-in fade-in duration-500">
      <div className="grid grid-cols-12 gap-8">
        
        {/* Central Swap Interface (7 Columns) */}
        <div className="col-span-12 lg:col-span-7 space-y-8">
          
          <div className="flex items-end justify-between">
            <div>
              <h2 className="text-[44px] font-extrabold font-headline tracking-tighter leading-none text-on-surface">
                {Number(btcRate).toFixed(2)}
              </h2>
              <div className="flex items-center gap-2 mt-2">
                <span className="bg-tertiary/10 text-tertiary text-xs px-2 py-0.5 rounded-full font-bold">+4.28%</span>
                <span className="text-on-surface-variant text-sm font-medium">BTC / USDT</span>
              </div>
            </div>
            <div className="w-48 h-16 opacity-50">
              <svg className="w-full h-full" viewBox="0 0 100 30">
                <path className="text-primary" d="M0 25 L10 22 L20 28 L30 15 L40 18 L50 10 L60 12 L70 5 L80 8 L90 2 L100 6" fill="none" stroke="currentColor" strokeWidth="2"></path>
              </svg>
            </div>
          </div>

          {/* Main Swap Card */}
          <div className="bg-surface-container rounded-xl p-8 border border-outline-variant/15 shadow-xl space-y-6 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 hero-gradient opacity-40"></div>
            
            {/* From Section */}
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs font-semibold uppercase tracking-widest text-on-surface-variant">
                <span>Отдаете</span>
                <span>Баланс: {isSwapped ? '12,402.00 USDT' : '1.428 BTC'}</span>
              </div>
              <div className="bg-surface-container-lowest p-5 rounded-lg flex items-center justify-between border border-transparent focus-within:border-primary/40 transition-all">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-surface-container-highest flex items-center justify-center text-xl shadow-inner">
                    {currencyFlags[fromCurrency] || '💱'}
                  </div>
                  <div>
                    <div className="text-lg font-bold font-headline text-on-surface">{fromCurrency}</div>
                    <div className="text-xs text-on-surface-variant">{fromCurrency === 'BTC' ? 'Биткоин' : 'Tether USD'}</div>
                  </div>
                </div>
                <input 
                  className="bg-transparent border-none text-right text-2xl font-bold font-headline focus:ring-0 w-40 p-0 text-on-surface outline-none" 
                  type="text" 
                  value={fromAmount}
                  onChange={(e) => setFromAmount(e.target.value)}
                />
              </div>
            </div>

            {/* Swap Divider */}
            <div className="relative flex justify-center h-4">
              <div className="absolute top-1/2 -translate-y-1/2 w-full h-[1px] bg-outline-variant/20"></div>
              <button 
                onClick={() => setIsSwapped(!isSwapped)}
                className="relative z-10 w-10 h-10 rounded-full bg-surface-container-high border border-outline-variant/15 flex items-center justify-center hover:scale-110 transition-transform text-primary shadow-xl cursor-pointer"
              >
                <span className="material-symbols-outlined" style={{ fontVariationSettings: "'FILL' 0" }}>swap_vert</span>
              </button>
            </div>

            {/* To Section */}
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs font-semibold uppercase tracking-widest text-on-surface-variant">
                <span>Получаете</span>
                <span>Баланс: {!isSwapped ? '12,402.00 USDT' : '1.428 BTC'}</span>
              </div>
              <div className="bg-surface-container-lowest p-5 rounded-lg flex items-center justify-between border border-transparent transition-all">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-surface-container-highest flex items-center justify-center text-xl shadow-inner">
                    {currencyFlags[toCurrency] || '💱'}
                  </div>
                  <div>
                    <div className="text-lg font-bold font-headline text-on-surface">{toCurrency}</div>
                    <div className="text-xs text-on-surface-variant">{toCurrency === 'USDT' ? 'Tether USD' : 'Биткоин'}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold font-headline text-on-surface">{estimatedTo}</div>
                  <div className="text-xs text-tertiary">Оценочная стоимость</div>
                </div>
              </div>
            </div>

            {/* Details Breakdown */}
            <div className="bg-surface-container-low rounded-lg p-5 space-y-3 border border-outline-variant/5">
              <div className="flex justify-between text-sm">
                <span className="text-on-surface-variant">Обменный курс</span>
                <span className="font-medium text-on-surface">1 {fromCurrency} = {currentRate.toFixed(4)} {toCurrency}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-on-surface-variant">Комиссия (0.1%)</span>
                <span className="font-medium text-on-surface">{fee} {toCurrency}</span>
              </div>
              <div className="flex justify-between text-sm pt-3 border-t border-outline-variant/10 mt-3">
                <span className="text-on-surface">Итого к получению</span>
                <span className="text-primary font-bold text-base">{total} {toCurrency}</span>
              </div>
            </div>

            <button className="w-full hero-gradient text-on-primary-container font-bold py-5 rounded-lg text-sm uppercase tracking-widest shadow-lg shadow-primary/20 active:scale-[0.99] transition-transform">
              Совершить Обмен
            </button>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="bg-surface-container-low p-6 rounded-xl border border-outline-variant/10 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-bl-full group-hover:bg-primary/10 transition-colors"></div>
              <div className="flex items-center gap-3 mb-4">
                <span className="material-symbols-outlined text-primary text-sm" style={{ fontVariationSettings: "'FILL' 1" }}>bolt</span>
                <span className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Уровень ликвидности</span>
              </div>
              <div className="text-2xl font-headline font-bold text-on-surface">Отлично</div>
              <div className="mt-4 h-1.5 bg-surface-container rounded-full overflow-hidden">
                <div className="h-full hero-gradient w-[92%]"></div>
              </div>
            </div>
            <div className="bg-surface-container-low p-6 rounded-xl border border-outline-variant/10">
              <div className="flex items-center gap-3 mb-4">
                <span className="material-symbols-outlined text-primary text-sm">speed</span>
                <span className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Время исп.</span>
              </div>
              <div className="text-2xl font-headline font-bold text-on-surface">&lt; 2.4с</div>
              <p className="text-xs text-on-surface-variant mt-2">Мгновенные переводы доступны</p>
            </div>
          </div>
        </div>

        {/* Side Panel (5 Columns) */}
        <div className="col-span-12 lg:col-span-5 space-y-8">
          
          <div className="bg-surface-container-low rounded-xl p-6 border border-outline-variant/10 h-fit">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-headline font-bold uppercase tracking-[0.1em] text-xs text-on-surface">Тренды рынка</h3>
              <span className="material-symbols-outlined text-on-surface-variant text-lg">more_horiz</span>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between group cursor-pointer hover:bg-surface-container rounded-lg p-3 border border-transparent hover:border-outline-variant/10 transition-all">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-surface-container-highest flex items-center justify-center text-xs font-bold text-on-surface shadow-inner">ETH</div>
                  <div>
                    <div className="text-sm font-bold text-on-surface">Эфириум</div>
                    <div className="text-[10px] text-on-surface-variant">ETH / USDT</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-on-surface">2,412.00</div>
                  <div className="text-[10px] text-tertiary font-bold">+1.2%</div>
                </div>
              </div>
              <div className="flex items-center justify-between group cursor-pointer hover:bg-surface-container rounded-lg p-3 border border-transparent hover:border-outline-variant/10 transition-all">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-surface-container-highest flex items-center justify-center text-xs font-bold text-on-surface shadow-inner">SOL</div>
                  <div>
                    <div className="text-sm font-bold text-on-surface">Солана</div>
                    <div className="text-[10px] text-on-surface-variant">SOL / USDT</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-on-surface">144.50</div>
                  <div className="text-[10px] text-error font-bold">-0.8%</div>
                </div>
              </div>
              <div className="flex items-center justify-between group cursor-pointer hover:bg-surface-container rounded-lg p-3 border border-transparent hover:border-outline-variant/10 transition-all">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-surface-container-highest flex items-center justify-center text-xs font-bold text-on-surface shadow-inner">ADA</div>
                  <div>
                    <div className="text-sm font-bold text-on-surface">Кардано</div>
                    <div className="text-[10px] text-on-surface-variant">ADA / USDT</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-on-surface">0.452</div>
                  <div className="text-[10px] text-tertiary font-bold">+2.1%</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-surface-container rounded-xl p-6 border border-outline-variant/10 flex-1 shadow-lg shadow-black/30">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-headline font-bold uppercase tracking-[0.1em] text-xs text-on-surface">Недавняя история</h3>
              <button className="text-[10px] font-bold text-primary uppercase tracking-tighter hover:underline">Смотреть все</button>
            </div>
            <div className="space-y-6">
              <div className="flex gap-4 items-start border-l-2 border-primary/40 pl-4 py-1">
                <div className="flex-1">
                  <div className="flex justify-between mb-1">
                    <span className="text-xs font-bold text-on-surface">Обмен BTC на USDT</span>
                    <span className="text-[10px] text-on-surface-variant">2 мин назад</span>
                  </div>
                  <div className="text-sm text-on-surface-variant">Успешная транзакция <span className="text-on-surface font-medium">0.12 BTC</span></div>
                </div>
              </div>
              <div className="flex gap-4 items-start border-l-2 border-outline-variant/20 pl-4 py-1 opacity-70">
                <div className="flex-1">
                  <div className="flex justify-between mb-1">
                    <span className="text-xs font-bold text-on-surface">Обмен SOL на BTC</span>
                    <span className="text-[10px] text-on-surface-variant">1 час назад</span>
                  </div>
                  <div className="text-sm text-on-surface-variant">Успешная транзакция <span className="text-on-surface font-medium">45.0 SOL</span></div>
                </div>
              </div>
              <div className="flex gap-4 items-start border-l-2 border-outline-variant/20 pl-4 py-1 opacity-70">
                <div className="flex-1">
                  <div className="flex justify-between mb-1">
                    <span className="text-xs font-bold text-on-surface">Обмен USDT на ETH</span>
                    <span className="text-[10px] text-on-surface-variant">3 часа назад</span>
                  </div>
                  <div className="text-sm text-on-surface-variant">Успешная транзакция <span className="text-on-surface font-medium">1,200.0 USDT</span></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
