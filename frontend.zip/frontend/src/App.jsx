import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { Exchange } from './pages/Exchange';
import { Alerts } from './pages/Alerts';

export default function App() {
  return (
    <Router>
      <AppProvider>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="exchange" element={<Exchange />} />
            <Route path="alerts" element={<Alerts />} />
          </Route>
        </Routes>
      </AppProvider>
    </Router>
  );
}
