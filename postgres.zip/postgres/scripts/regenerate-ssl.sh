#!/usr/bin/env bash
# Пересоздать ключ и сертификат внутри образа: пересоберите образ postgres.
# Для кастомного CN/SAN отредактируйте openssl в postgres/Dockerfile и выполните:
#   docker compose build postgres --no-cache

set -euo pipefail
echo "TLS для PostgreSQL вшит в образ (postgres/Dockerfile)."
echo "Пересборка: cd /path/to/MPC && docker compose build postgres --no-cache && docker compose up -d postgres"
