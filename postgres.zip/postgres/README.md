# PostgreSQL: TLS и удалённый доступ

Образ собирается из **`Dockerfile`**: внутри генерируется **самоподписанный** сертификат сервера, включается **SSL**, подключается **`pg_hba.conf`**.

## Поведение `pg_hba.conf`

| Источник | TLS | Комментарий |
|----------|-----|----------------|
| Сеть **172.16.0.0/12** (типичный Docker bridge) | не обязателен | Контейнеры в том же `docker-compose`, приложение `api` с `DB_SSL=false`. |
| **127.0.0.1** | не обязателен | Локальные TCP-подключения внутри контейнера. |
| Любые другие адреса (**удалённый клиент**) | **обязателен** (`hostssl`) | Нужен `sslmode=require` (или строже) и доверие к сертификату. |

## Порт на хосте

По умолчанию в **`docker-compose.yml`** проброшен **`5433` → 5432`** в контейнере (часто порт **5432** на машине уже занят локальным Postgres или другим проектом). С хоста подключайтесь к **`localhost:5433`**. Контейнер **`api`** в том же compose по-прежнему использует **`postgres:5432`**.

Если нужен именно **5432** на хосте — освободите порт и в `docker-compose.yml` замените на `'5432:5432'`.

## Удалённое подключение с другой машины

1. Убедитесь, что на сервере порт **5433** (или тот, что в `ports:`) открыт в firewall / security group.
2. Скопируйте сертификат сервера на клиент (один раз):

```bash
docker cp currency-postgres:/etc/postgresql/ssl/server.crt ./postgres-server.crt
```

3. Подключение через `psql` (самоподписанный сертификат — без строгой проверки CN):

```bash
PGSSLROOTCERT=./postgres-server.crt PGSSLMODE=verify-ca psql "host=SERVER_IP port=5433 dbname=currency_db user=postgres sslmode=verify-ca"
```

Или для первых тестов (не для продакшена):

```bash
psql "host=SERVER_IP port=5433 dbname=currency_db user=postgres sslmode=require"
```

В Node/pg задайте в `.env`: `DB_SSL=true`, `DB_SSLMODE=require`, `DB_SSL_REJECT_UNAUTHORIZED=false` (для self-signed) или укажите `DB_SSL_CA_PATH` к файлу `postgres-server.crt`.

## Только localhost на хосте

Если не нужен доступ из интернета к порту Postgres, в **`docker-compose.yml`** замените блок `ports` у сервиса `postgres` на, например:

```yaml
ports:
  - '127.0.0.1:5433:5432'
```

Удалённые пользователи тогда подключаются через **SSH-туннель** (см. `infra/security/docs-remote-db.md`).

## Ограничение по IP

Отредактируйте **`postgres/pg_hba.conf`**: перед строками `hostssl ... 0.0.0.0/0` добавьте, например:

```
hostssl all  all  203.0.113.0/24  scram-sha-256
```

и удалите широкие `0.0.0.0/0`, либо оставьте узкие подсети. Пересоберите образ и перезапустите контейнер.

## Пересборка образа после смены `pg_hba` или сертификата

```bash
docker compose build postgres --no-cache
docker compose up -d postgres
```
