const OLLAMA_BASE_URL = (process.env.OLLAMA_BASE_URL || 'http://localhost:11434').replace(/\/$/, '');
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'llama3.2';
const OLLAMA_DISABLED = String(process.env.OLLAMA_DISABLED || '').toLowerCase() === 'true';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const OPENAI_BASE_URL = (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';

const REQUEST_TIMEOUT_MS = Math.min(
  Math.max(Number(process.env.ASSISTANT_TIMEOUT_MS || 30000), 3000),
  300000
);

function buildContextText({ message, cfg, summaryShort, alertsRows }) {
  const alertsText = alertsRows.length
    ? alertsRows
        .map(
          (a) =>
            `${new Date(a.ts).toISOString()} | ${cfg.base}/${a.quote_currency} | ${Number(a.change_percent).toFixed(2)}%`
        )
        .join('\n')
    : 'Нет недавних алертов.';

  return [
    `Вопрос пользователя: ${message}`,
    `Базовая валюта: ${cfg.base}`,
    `Текущие курсы (выборка): ${summaryShort || 'нет данных'}`,
    `Последние алерты:\n${alertsText}`
  ].join('\n\n');
}

function buildSystemPrompt() {
  return [
    'Ты финансовый ассистент дашборда мониторинга курсов валют.',
    'Отвечай на русском языке кратко и по делу.',
    'Используй только предоставленные данные из контекста (курсы и алерты).',
    'Если данных недостаточно, прямо скажи это.',
    'Не выдумывай курсы, которых нет в контексте.'
  ].join(' ');
}

/** Короткая сводка курсов: не раздуваем промпт на десятки тысяч символов */
export function buildRatesSummaryShort(latestRows, cfg, maxPairs = 40) {
  if (!Array.isArray(latestRows) || !latestRows.length) return '';
  const slice = latestRows.slice(0, maxPairs);
  const rest = latestRows.length - slice.length;
  const body = slice.map((r) => `${cfg.base}/${r.quote_currency}=${Number(r.rate).toFixed(4)}`).join(', ');
  return rest > 0 ? `${body} … (+${rest} пар)` : body;
}

function looksLikeRateQuestion(message) {
  const m = String(message || '');
  return (
    /\b(AUD|BRL|CAD|CHF|CNY|CZK|DKK|EUR|GBP|HKD|HUF|IDR|ILS|INR|ISK|JPY|KRW|MXN|MYR|NOK|NZD|PHP|PLN|RON|SEK|SGD|THB|TRY|ZAR|BTC|ETH|USDT|USD)\b/i.test(
      m
    ) ||
    /курс|rate|валют|алерт|обмен|сколько\s+стоит|цена|динамик|прогноз|сравни|\/[A-Z]{3}/i.test(m) ||
    /евр|доллар|фунт|юан|йен|рубл|тенге|лир|франк|злот|крон|вон|рупи|песо|реал|биткоин|эфир/i.test(m)
  );
}

/** Сообщение без запроса курсов — приветствие, благодарность и т.п. */
function isCasualSmalltalk(message) {
  const raw = String(message || '').trim();
  if (!raw) return true;
  if (looksLikeRateQuestion(raw)) return false;

  const t = raw.toLowerCase().replace(/[!?.…,:;]+$/g, '').replace(/\s+/g, ' ');
  if (t.length > 80) return false;

  // Не используем \b — для кириллицы в JS это ненадёжно
  const patterns = [
    /^(привет|здравствуй(те)?|добрый\s+(день|вечер|утро)|hi|hello|hey|ку|qq|хай)(\s*[!.?…]*)?$/i,
    /^(пока|до свидания|bye|спасибо|благодарю|thanks|thank you)(\s*[!.?…]*)?$/i,
    /^(как дела|как ты|что нового)(\s*[!.?…]*)?$/i,
    /^(ок|окей|ладно|понятно|ясно|хорошо|да|нет)(\s*[!.?…]*)?$/i,
    /^(здрасьте|салют)(\s*[!.?…]*)?$/i
  ];
  return patterns.some((re) => re.test(t));
}

export function buildLocalAssistantReply({ message, cfg, latestRows, summaryShort, alertsRows }) {
  const lower = String(message || '').toLowerCase();
  const rateMap = {};
  for (const r of latestRows || []) {
    const q = String(r.quote_currency || '').toUpperCase();
    if (q) rateMap[q] = Number(r.rate);
  }

  const hits = [];
  const codesInMessage = String(message || '').toUpperCase().match(/\b[A-Z]{3}\b/g) || [];
  const seen = new Set();
  for (const code of codesInMessage) {
    if (seen.has(code)) continue;
    seen.add(code);
    if (code === String(cfg.base || '').toUpperCase()) continue;
    if (Number.isFinite(rateMap[code])) {
      hits.push(`${cfg.base}/${code} = ${rateMap[code].toFixed(4)}`);
    }
  }

  const synonyms = [
    ['евро', 'EUR'],
    ['доллар', 'USD'],
    ['фунт', 'GBP'],
    ['йен', 'JPY'],
    ['юань', 'CNY'],
    ['лир', 'TRY'],
    ['франк', 'CHF'],
    ['крон', 'SEK'],
    ['злот', 'PLN'],
    ['вон', 'KRW'],
    ['рупи', 'INR'],
    ['песо', 'MXN'],
    ['реал', 'BRL'],
    ['биткоин', 'BTC'],
    ['эфир', 'ETH']
  ];
  for (const [word, code] of synonyms) {
    if (lower.includes(word) && Number.isFinite(rateMap[code]) && !hits.some((h) => h.includes(`/${code}`))) {
      hits.push(`${cfg.base}/${code} = ${rateMap[code].toFixed(4)}`);
    }
  }

  const specific = hits.length ? `По запросу: ${hits.join('; ')}.` : '';

  if (isCasualSmalltalk(message) && !hits.length) {
    return [
      'Привет! Я помогаю по курсам и уведомлениям в этом дашборде.',
      `Сейчас база: ${cfg.base}. Спросите, например: «курс EUR» или «что с JPY».`,
      '',
      'Для свободного диалога подключите Ollama или задайте OPENAI_API_KEY в backend/.env (см. backend/.env.example).'
    ].join('\n');
  }

  const setupHint =
    'Полноценный чат-ответ: OPENAI_API_KEY или локальный Ollama (OLLAMA_MODEL, например llama3.2) — см. backend/.env.example.';

  const parts = [
    'Локальный режим: отвечаю по данным дашборда, без внешней нейросети.',
    specific || (summaryShort ? `Актуальные курсы (фрагмент): ${summaryShort}.` : 'Курсы пока не загружены.'),
    alertsRows.length
      ? `Последние алерты: ${alertsRows.map((a) => `${a.quote_currency} ${Number(a.change_percent).toFixed(2)}%`).join('; ')}.`
      : 'Свежих алертов нет.',
    '',
    setupHint
  ];

  return parts.filter(Boolean).join('\n');
}

async function getOpenAiCompatibleReply({ message, cfg, summaryShort, alertsRows }) {
  if (!OPENAI_API_KEY) return null;

  const systemPrompt = buildSystemPrompt();
  const userContent = buildContextText({ message, cfg, summaryShort, alertsRows });

  const response = await fetch(`${OPENAI_BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      temperature: 0.2,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userContent }
      ]
    }),
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS)
  });

  if (!response.ok) {
    const t = await response.text();
    throw new Error(`OpenAI-compatible API ${response.status}: ${t.slice(0, 500)}`);
  }

  const data = await response.json();
  const text = String(data?.choices?.[0]?.message?.content || '').trim();
  return text || null;
}

async function getOllamaAssistantReply({ message, cfg, summaryShort, alertsRows }) {
  if (OLLAMA_DISABLED) return null;

  const systemPrompt = buildSystemPrompt();
  const contextPrompt = buildContextText({ message, cfg, summaryShort, alertsRows });

  const response = await fetch(`${OLLAMA_BASE_URL}/api/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: OLLAMA_MODEL,
      stream: false,
      options: {
        temperature: 0.2
      },
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: contextPrompt }
      ]
    }),
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS)
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Ollama API ${response.status}: ${errorText.slice(0, 500)}`);
  }

  const data = await response.json();
  const text = String(data?.message?.content || '').trim();
  return text || null;
}

/**
 * Порядок: OpenAI-совместимый API (если задан ключ) → Ollama → null (тогда сработает локальный fallback в роуте).
 */
export async function getAssistantLlmReply({ message, cfg, summaryShort, alertsRows }) {
  try {
    const openai = await getOpenAiCompatibleReply({ message, cfg, summaryShort, alertsRows });
    if (openai) return { provider: 'openai_compatible', text: openai };
  } catch (e) {
    console.error('OpenAI-compatible assistant failed:', e.message);
  }

  try {
    const ollama = await getOllamaAssistantReply({ message, cfg, summaryShort, alertsRows });
    if (ollama) return { provider: 'ollama', text: ollama };
  } catch (e) {
    console.error('Ollama assistant failed:', e.message);
  }

  return { provider: null, text: null };
}
