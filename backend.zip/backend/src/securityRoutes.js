import { Router } from 'express';
import { pool } from './db.js';
import { hashPassword, verifyPassword, signSession, verifySession, randomPassword } from './cryptoAuth.js';

export const securityRouter = Router();

const TOKEN_TTL_MS = Math.max(Number(process.env.AUTH_TOKEN_TTL_MS || 604800000), 60000);

export async function bootstrapAdminUser() {
  const email = String(process.env.ADMIN_BOOTSTRAP_EMAIL || '').trim().toLowerCase();
  const password = String(process.env.ADMIN_BOOTSTRAP_PASSWORD || '');
  if (!email || !password) return;

  const ph = hashPassword(password);
  await pool.query(
    `
    INSERT INTO app_users (email, password_hash, role, display_name)
    VALUES ($1, $2, 'admin', 'Bootstrap Admin')
    ON CONFLICT (email) DO UPDATE
    SET password_hash = EXCLUDED.password_hash,
        role = 'admin',
        disabled_at = NULL
    `,
    [email, ph]
  );
}

async function auditLog(action, details, req) {
  const ip = req.get('X-Forwarded-For')?.split(',')[0]?.trim() || req.ip || req.socket?.remoteAddress;
  try {
    await pool.query(
      `INSERT INTO security_audit_logs (action, details, ip) VALUES ($1, $2::jsonb, $3)`,
      [action, JSON.stringify(details ?? {}), ip || null]
    );
  } catch (e) {
    console.error('auditLog failed:', e.message);
  }
}

function requireAdmin(req, res, next) {
  const adminTok = process.env.ADMIN_API_TOKEN || '';
  const header = req.get('X-Admin-Token') || '';
  if (adminTok && header === adminTok) {
    req.adminAuth = 'token';
    return next();
  }
  const auth = req.get('Authorization') || '';
  if (auth.startsWith('Bearer ')) {
    const payload = verifySession(auth.slice(7).trim());
    if (payload?.role === 'admin') {
      req.adminAuth = 'jwt';
      req.adminUserId = payload.sub;
      return next();
    }
  }
  return res.status(403).json({ error: 'Forbidden' });
}

securityRouter.post('/api/auth/login', async (req, res) => {
  if (!req.body || typeof req.body !== 'object') {
    res.status(400).json({ error: 'JSON body required' });
    return;
  }
  const email = String(req.body?.email || '')
    .trim()
    .toLowerCase();
  const password = String(req.body?.password || '');
  if (!email || !password) {
    res.status(400).json({ error: 'email and password required' });
    return;
  }

  const secret = process.env.AUTH_JWT_SECRET || '';
  if (!secret) {
    res.status(503).json({ error: 'AUTH_JWT_SECRET is not configured' });
    return;
  }

  const r = await pool.query(
    `SELECT id, email, role, password_hash, disabled_at FROM app_users WHERE lower(email) = lower($1)`,
    [email]
  );
  const row = r.rows[0];
  if (!row || row.disabled_at) {
    await auditLog('login_failed', { email }, req);
    res.status(401).json({ error: 'Invalid credentials' });
    return;
  }
  if (!verifyPassword(password, row.password_hash)) {
    await auditLog('login_failed', { email }, req);
    res.status(401).json({ error: 'Invalid credentials' });
    return;
  }

  const token = signSession(
    {
      sub: row.id,
      role: row.role,
      email: row.email,
      exp: Date.now() + TOKEN_TTL_MS
    },
    secret
  );
  await auditLog('login_ok', { userId: row.id, email: row.email }, req);
  res.json({ token, role: row.role, email: row.email });
});

securityRouter.get('/api/admin/users', requireAdmin, async (req, res) => {
  const r = await pool.query(
    `
    SELECT id, email, role, display_name, created_at, disabled_at
    FROM app_users
    ORDER BY id ASC
    `
  );
  res.json(r.rows);
});

securityRouter.post('/api/admin/users', requireAdmin, async (req, res) => {
  const email = String(req.body?.email || '')
    .trim()
    .toLowerCase();
  const displayName = String(req.body?.display_name || '').trim() || null;
  const role = req.body?.role === 'admin' ? 'admin' : 'user';
  let plain = String(req.body?.password || '').trim();
  if (!plain) plain = randomPassword();
  if (!email) {
    res.status(400).json({ error: 'email required' });
    return;
  }

  const ph = hashPassword(plain);
  try {
    const ins = await pool.query(
      `
      INSERT INTO app_users (email, password_hash, role, display_name)
      VALUES ($1, $2, $3, $4)
      RETURNING id, email, role, display_name, created_at, disabled_at
      `,
      [email, ph, role, displayName]
    );
    await auditLog('user_create', { id: ins.rows[0].id, email }, req);
    res.status(201).json({ ...ins.rows[0], temporaryPassword: plain });
  } catch (e) {
    if (e.code === '23505') {
      res.status(409).json({ error: 'Email already exists' });
      return;
    }
    throw e;
  }
});

securityRouter.patch('/api/admin/users/:id/disable', requireAdmin, async (req, res) => {
  const id = Number(req.params.id, 10);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: 'invalid id' });
    return;
  }
  const r = await pool.query(
    `UPDATE app_users SET disabled_at = NOW() WHERE id = $1 AND disabled_at IS NULL RETURNING id, email`,
    [id]
  );
  if (!r.rowCount) {
    res.status(404).json({ error: 'User not found or already disabled' });
    return;
  }
  await auditLog('user_disable', { id, email: r.rows[0].email }, req);
  res.json({ ok: true, user: r.rows[0] });
});

securityRouter.delete('/api/admin/users/:id/secure-purge', requireAdmin, async (req, res) => {
  const id = Number(req.params.id, 10);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: 'invalid id' });
    return;
  }

  const u = await pool.query(`SELECT id, email, disabled_at FROM app_users WHERE id = $1`, [id]);
  const row = u.rows[0];
  if (!row) {
    res.status(404).json({ error: 'User not found' });
    return;
  }
  if (!row.disabled_at) {
    res.status(400).json({ error: 'Disable user first (PATCH .../disable), then purge' });
    return;
  }

  await pool.query(`DELETE FROM app_users WHERE id = $1`, [id]);
  await auditLog('user_secure_purge', { id, email: row.email }, req);
  res.json({ ok: true, message: 'User record permanently deleted (GDPR-style wipe)' });
});

securityRouter.get('/api/admin/audit', requireAdmin, async (_req, res) => {
  const r = await pool.query(
    `SELECT id, ts, action, details, ip FROM security_audit_logs ORDER BY ts DESC LIMIT 200`
  );
  res.json(r.rows);
});
