import { createHmac, randomBytes, scryptSync, timingSafeEqual } from 'crypto';

const SALT_LEN = 16;
const KEYLEN = 64;

export function hashPassword(password) {
  const salt = randomBytes(SALT_LEN);
  const key = scryptSync(String(password), salt, KEYLEN);
  return `${salt.toString('hex')}:${key.toString('hex')}`;
}

export function verifyPassword(password, stored) {
  if (!stored || typeof stored !== 'string' || !stored.includes(':')) return false;
  const [saltHex, keyHex] = stored.split(':');
  if (!saltHex || !keyHex) return false;
  try {
    const salt = Buffer.from(saltHex, 'hex');
    const key = Buffer.from(keyHex, 'hex');
    const derived = scryptSync(String(password), salt, KEYLEN);
    if (key.length !== derived.length) return false;
    return timingSafeEqual(key, derived);
  } catch {
    return false;
  }
}

export function signSession(payload, secret) {
  const sec = secret || process.env.AUTH_JWT_SECRET || '';
  if (!sec) return null;
  const body = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = createHmac('sha256', sec).update(body).digest('base64url');
  return `${body}.${sig}`;
}

export function verifySession(token, secret) {
  const sec = secret || process.env.AUTH_JWT_SECRET || '';
  if (!sec || !token || typeof token !== 'string') return null;
  const dot = token.indexOf('.');
  if (dot < 0) return null;
  const body = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  if (!body || !sig) return null;
  const expected = createHmac('sha256', sec).update(body).digest('base64url');
  try {
    const a = Buffer.from(sig, 'utf8');
    const b = Buffer.from(expected, 'utf8');
    if (a.length !== b.length) return null;
    if (!timingSafeEqual(a, b)) return null;
  } catch {
    return null;
  }
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (payload.exp && Date.now() > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}

export function randomPassword() {
  return randomBytes(16).toString('base64url');
}
