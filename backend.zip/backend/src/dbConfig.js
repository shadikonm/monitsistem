import fs from 'fs';
import pg from 'pg';

const { Pool } = pg;

function buildSslOption() {
  const sslFlag = String(process.env.DB_SSL || '').toLowerCase() === 'true';
  const mode = String(process.env.DB_SSLMODE || '').toLowerCase();
  const wantSsl =
    sslFlag || mode === 'require' || mode === 'verify-ca' || mode === 'verify-full';

  if (!wantSsl) return undefined;

  const reject =
    String(process.env.DB_SSL_REJECT_UNAUTHORIZED || 'false').toLowerCase() !== 'false';

  const ssl = { rejectUnauthorized: reject };
  const caPath = process.env.DB_SSL_CA_PATH || '';
  if (caPath && fs.existsSync(caPath)) {
    ssl.ca = fs.readFileSync(caPath, 'utf8');
  }
  return ssl;
}

export function createPool() {
  return new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT || 5432),
    database: process.env.DB_NAME || 'currency_db',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
    ssl: buildSslOption()
  });
}
