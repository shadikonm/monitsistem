import pg from 'pg';

const { Pool } = pg;

export const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 5432),
  database: process.env.DB_NAME || 'currency_db',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres'
});

export async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS rates (
      id SERIAL PRIMARY KEY,
      ts TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      base_currency TEXT NOT NULL,
      quote_currency TEXT NOT NULL,
      rate NUMERIC(18, 8) NOT NULL
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS alerts (
      id SERIAL PRIMARY KEY,
      ts TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      quote_currency TEXT NOT NULL,
      prev_rate NUMERIC(18, 8) NOT NULL,
      current_rate NUMERIC(18, 8) NOT NULL,
      change_percent NUMERIC(10, 4) NOT NULL,
      message TEXT NOT NULL
    );
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_rates_pair_ts
    ON rates (base_currency, quote_currency, ts DESC);
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_alerts_ts
    ON alerts (ts DESC);
  `);
}
