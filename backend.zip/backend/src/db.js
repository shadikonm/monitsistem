import { createPool } from './dbConfig.js';

export const pool = createPool();

export async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS rates (
      id SERIAL PRIMARY KEY,
      ts TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      base_currency TEXT NOT NULL,
      quote_currency TEXT NOT NULL,
      rate NUMERIC(18, 8) NOT NULL
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS alerts (
      id SERIAL PRIMARY KEY,
      ts TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      quote_currency TEXT NOT NULL,
      prev_rate NUMERIC(18, 8) NOT NULL,
      current_rate NUMERIC(18, 8) NOT NULL,
      change_percent NUMERIC(10, 4) NOT NULL,
      message TEXT NOT NULL
    );
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_rates_pair_ts
    ON rates (base_currency, quote_currency, ts DESC);
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_alerts_ts
    ON alerts (ts DESC);
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS app_users (
      id SERIAL PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'user')),
      display_name TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      disabled_at TIMESTAMPTZ
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS security_audit_logs (
      id SERIAL PRIMARY KEY,
      ts TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      action TEXT NOT NULL,
      details JSONB,
      ip TEXT
    );
  `);
}
