import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import cron from 'node-cron';
import { initDb, pool } from './db.js';
import { getCurrenciesConfig, getDefaultSyncCron, syncRates, fetchKlines, SOURCE_MODE, BASE_CURRENCY, BINANCE_SYMBOLS } from './currencyService.js';

const app = express();
const PORT = Number(process.env.PORT || 4000);
const alertClients = new Set();
const rateClients = new Set();
const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL || 'http://localhost:11434';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'qwen3.5-cloud';

app.use(cors());
app.use(express.json());

function buildLocalAssistantReply({ message, cfg, summary, alertsRows }) {
  return [
    'Локальный ИИ-ассистент (fallback режим):',
    `Вы спросили: "${message}"`,
    `Текущие курсы: ${summary || 'нет данных'}.`,
    alertsRows.length
      ? `Последние алерты: ${alertsRows.map((a) => `${a.quote_currency} ${Number(a.change_percent).toFixed(2)}%`).join('; ')}`
      : 'Резких изменений пока не обнаружено.'
  ].join('\n');
}

async function getOllamaAssistantReply({ message, cfg, summary, alertsRows }) {
  const alertsText = alertsRows.length
    ? alertsRows
        .map(
          (a) =>
            `${new Date(a.ts).toISOString()} | ${cfg.base}/${a.quote_currency} | ${Number(a.change_percent).toFixed(2)}%`
        )
        .join('\n')
    : 'Нет недавних алертов.';

  const systemPrompt = [
    'Ты финансовый ассистент дашборда мониторинга курсов.',
    'Отвечай на русском языке кратко и по делу.',
    'Используй только предоставленные данные из контекста.',
    'Если данных недостаточно, прямо скажи это.'
  ].join(' ');

  const contextPrompt = [
    `Вопрос пользователя: ${message}`,
    `Базовая валюта: ${cfg.base}`,
    `Текущие курсы: ${summary || 'нет данных'}`,
    `Последние алерты:\n${alertsText}`
  ].join('\n\n');

  const response = await fetch(`${OLLAMA_BASE_URL}/api/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: OLLAMA_MODEL,
      stream: false,
      options: {
        temperature: 0.2
      },
      messages: [
        {
          role: 'system',
          content: systemPrompt
        },
        {
          role: 'user',
          content: contextPrompt
        }
      ]
    })
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Ollama API error ${response.status}: ${errorText}`);
  }

  const data = await response.json();
  const text = String(data?.message?.content || '').trim();
  return text || null;
}

function broadcastAlert(alert) {
  const payload = `data: ${JSON.stringify(alert)}\n\n`;
  for (const res of alertClients) {
    res.write(payload);
  }
}

function broadcastRates(rows) {
  const payload = `data: ${JSON.stringify(rows)}\n\n`;
  for (const res of rateClients) {
    res.write(payload);
  }
}

async function getLatestRatesRows() {
  const cfg = getCurrenciesConfig();
  const result = await pool.query(
    `
    SELECT DISTINCT ON (quote_currency)
      quote_currency,
      rate,
      ts
    FROM rates
    WHERE base_currency = $1
    ORDER BY quote_currency, ts DESC
    `,
    [cfg.base]
  );
  return result.rows;
}

app.get('/health', (_req, res) => {
  res.json({ ok: true, now: new Date().toISOString() });
});

app.get('/api/config', (_req, res) => {
  res.json(getCurrenciesConfig());
});

app.get('/api/rates/latest', async (_req, res) => {
  const rows = await getLatestRatesRows();
  res.json(rows);
});

app.get('/api/rates/history/:quote', async (req, res) => {
  const quote = String(req.params.quote || '').toUpperCase();
  const hours = Number(req.query.hours || 24);
  const cfg = getCurrenciesConfig();

  // First try DB data
  const result = await pool.query(
    `
    SELECT ts, rate
    FROM rates
    WHERE base_currency = $1
      AND quote_currency = $2
      AND ts >= NOW() - ($3::text || ' hours')::interval
    ORDER BY ts ASC
    `,
    [cfg.base, quote, String(hours)]
  );

  // For Binance mode: if DB has insufficient data, fetch from Binance klines API
  if (SOURCE_MODE === 'BINANCE_CRYPTO' && result.rows.length < 10) {
    try {
      const symbol = quote + BASE_CURRENCY;
      if (BINANCE_SYMBOLS.includes(symbol)) {
        const klines = await fetchKlines(symbol, hours);
        return res.json(klines);
      }
    } catch (err) {
      console.error('Klines fallback failed:', err.message);
    }
  }

  res.json(result.rows);
});

app.get('/api/alerts', async (_req, res) => {
  const result = await pool.query(
    `
    SELECT ts, quote_currency, prev_rate, current_rate, change_percent, message
    FROM alerts
    ORDER BY ts DESC
    LIMIT 50
    `
  );

  res.json(result.rows);
});

app.get('/api/alerts/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  alertClients.add(res);

  req.on('close', () => {
    alertClients.delete(res);
  });
});

app.get('/api/rates/stream', async (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  rateClients.add(res);
  const rows = await getLatestRatesRows();
  res.write(`data: ${JSON.stringify(rows)}\n\n`);

  req.on('close', () => {
    rateClients.delete(res);
  });
});

app.post('/api/assistant', async (req, res) => {
  const message = String(req.body?.message || '').trim();
  const cfg = getCurrenciesConfig();

  if (!message) {
    res.status(400).json({ error: 'message is required' });
    return;
  }

  const latestRows = await getLatestRatesRows();

  const alerts = await pool.query(
    `
    SELECT ts, quote_currency, change_percent, message
    FROM alerts
    ORDER BY ts DESC
    LIMIT 3
    `
  );

  const summary = latestRows
    .map((r) => `${cfg.base}/${r.quote_currency}=${Number(r.rate).toFixed(4)}`)
    .join(', ');

  let reply;
  try {
    reply = await getOllamaAssistantReply({
      message,
      cfg,
      summary,
      alertsRows: alerts.rows
    });
  } catch (error) {
    console.error('Ollama assistant failed, fallback to local mode:', error.message);
  }

  if (!reply) {
    reply = buildLocalAssistantReply({
      message,
      cfg,
      summary,
      alertsRows: alerts.rows
    });
  }

  res.json({ reply });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

async function start() {
  await initDb();

  async function performSync() {
    await syncRates(broadcastAlert);
    const latestRows = await getLatestRatesRows();
    broadcastRates(latestRows);
  }

  await performSync();

  const schedule = process.env.SYNC_CRON || getDefaultSyncCron();
  cron.schedule(schedule, async () => {
    try {
      await performSync();
    } catch (error) {
      console.error('Sync failed:', error.message);
    }
  });

  app.listen(PORT, () => {
    console.log(`Backend is running on http://localhost:${PORT}`);
  });
}

start().catch((error) => {
  console.error('Failed to start backend:', error);
  process.exit(1);
});
