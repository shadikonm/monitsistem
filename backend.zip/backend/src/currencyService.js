import { pool } from './db.js';

const SOURCE_MODE = (process.env.SOURCE_MODE || 'ECB').toUpperCase();
const BASE_CURRENCY = process.env.BASE_CURRENCY || 'USD';
const ECB_QUOTES = (process.env.QUOTE_CURRENCIES || 'EUR,KZT,GBP,CNY,JPY')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);
const BINANCE_SYMBOLS = (process.env.BINANCE_SYMBOLS || 'BTCUSDT,ETHUSDT,BNBUSDT,SOLUSDT')
  .split(',')
  .map((s) => s.trim().toUpperCase())
  .filter(Boolean);
const QUOTE_CURRENCIES =
  SOURCE_MODE === 'BINANCE_CRYPTO'
    ? BINANCE_SYMBOLS.map((symbol) =>
        symbol.endsWith(BASE_CURRENCY) ? symbol.slice(0, symbol.length - BASE_CURRENCY.length) : symbol
      )
    : ECB_QUOTES;
const ALERT_THRESHOLD_PERCENT = Number(process.env.ALERT_THRESHOLD_PERCENT || 2);
const ECB_DAILY_XML_URL =
  process.env.ECB_DAILY_XML_URL || 'https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml';
const BINANCE_API_BASE = process.env.BINANCE_API_BASE || 'https://api.binance.com';
const OFFICIAL_SOURCE_NAME = 'European Central Bank (ECB)';

function hoursToKlineInterval(hours) {
  if (hours <= 1) return { interval: '1m', limit: 60 };
  if (hours <= 6) return { interval: '5m', limit: 72 };
  if (hours <= 24) return { interval: '15m', limit: 96 };
  return { interval: '1h', limit: 168 };
}

export async function fetchKlines(symbol, hours) {
  const { interval, limit } = hoursToKlineInterval(hours);
  const url = `${BINANCE_API_BASE}/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Binance klines error: ${response.status}`);
  }
  const data = await response.json();
  return data.map((k) => ({
    ts: new Date(k[0]).toISOString(),
    rate: k[4] // close price
  }));
}

export { SOURCE_MODE, BASE_CURRENCY, BINANCE_SYMBOLS };

let lastSourceMeta = {
  provider: OFFICIAL_SOURCE_NAME,
  kind: 'ecb_daily',
  official: true,
  referenceDate: null,
  updateIntervalSeconds: 15
};

function parseEcbXml(xml) {
  const dateMatch = xml.match(/time=['"](\d{4}-\d{2}-\d{2})['"]/);
  const referenceDate = dateMatch ? dateMatch[1] : null;

  const eurRates = { EUR: 1 };
  const rateRegex = /currency=['"]([A-Z]{3})['"]\s+rate=['"]([0-9.]+)['"]/g;
  let match;
  while ((match = rateRegex.exec(xml)) !== null) {
    eurRates[match[1]] = Number(match[2]);
  }

  return { eurRates, referenceDate };
}

async function fetchLatestRates() {
  if (SOURCE_MODE === 'BINANCE_CRYPTO') {
    const symbolsParam = encodeURIComponent(JSON.stringify(BINANCE_SYMBOLS));
    const response = await fetch(`${BINANCE_API_BASE}/api/v3/ticker/price?symbols=${symbolsParam}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch Binance rates: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    const rows = Array.isArray(data) ? data : [data];
    const rates = {};

    for (const row of rows) {
      const symbol = String(row?.symbol || '').toUpperCase();
      const price = Number(row?.price);
      if (!symbol || !Number.isFinite(price)) continue;

      const quote = symbol.endsWith(BASE_CURRENCY) ? symbol.slice(0, symbol.length - BASE_CURRENCY.length) : symbol;
      rates[quote] = price;
    }

    lastSourceMeta = {
      provider: 'Binance Spot API',
      kind: 'binance_crypto',
      official: true,
      referenceDate: new Date().toISOString(),
      updateIntervalSeconds: 15
    };

    return rates;
  }

  const response = await fetch(ECB_DAILY_XML_URL);
  if (!response.ok) {
    throw new Error(`Failed to fetch ECB rates: ${response.status} ${response.statusText}`);
  }

  const xml = await response.text();
  const { eurRates, referenceDate } = parseEcbXml(xml);

  if (!eurRates.EUR || Object.keys(eurRates).length < 2) {
    throw new Error('Unexpected ECB XML response');
  }

  if (!eurRates[BASE_CURRENCY]) {
    throw new Error(`Base currency ${BASE_CURRENCY} is not available in ECB reference rates`);
  }

  const rates = {};
  for (const quote of QUOTE_CURRENCIES) {
    if (!eurRates[quote]) {
      continue;
    }
    rates[quote] = eurRates[quote] / eurRates[BASE_CURRENCY];
  }

  lastSourceMeta = {
    provider: OFFICIAL_SOURCE_NAME,
    kind: 'ecb_daily',
    official: true,
    referenceDate,
    updateIntervalSeconds: 86400
  };

  return rates;
}

async function getLastRate(base, quote) {
  const result = await pool.query(
    `
    SELECT rate
    FROM rates
    WHERE base_currency = $1 AND quote_currency = $2
    ORDER BY ts DESC
    LIMIT 1
    `,
    [base, quote]
  );

  return result.rows[0] ? Number(result.rows[0].rate) : null;
}

async function saveRate(base, quote, rate) {
  await pool.query(
    `
    INSERT INTO rates (base_currency, quote_currency, rate)
    VALUES ($1, $2, $3)
    `,
    [base, quote, rate]
  );
}

async function saveAlert(quote, prevRate, currentRate, changePercent) {
  const message = `Резкое изменение ${BASE_CURRENCY}/${quote}: ${changePercent.toFixed(2)}%`;

  await pool.query(
    `
    INSERT INTO alerts (quote_currency, prev_rate, current_rate, change_percent, message)
    VALUES ($1, $2, $3, $4, $5)
    `,
    [quote, prevRate, currentRate, changePercent, message]
  );

  return {
    ts: new Date().toISOString(),
    quoteCurrency: quote,
    prevRate,
    currentRate,
    changePercent,
    message
  };
}

export async function syncRates(notifyAlert) {
  const rates = await fetchLatestRates();

  for (const quote of QUOTE_CURRENCIES) {
    const currentRate = Number(rates[quote]);
    if (!Number.isFinite(currentRate)) {
      continue;
    }

    const prevRate = await getLastRate(BASE_CURRENCY, quote);
    await saveRate(BASE_CURRENCY, quote, currentRate);

    if (prevRate && prevRate > 0) {
      const changePercent = ((currentRate - prevRate) / prevRate) * 100;
      if (Math.abs(changePercent) >= ALERT_THRESHOLD_PERCENT) {
        const alert = await saveAlert(quote, prevRate, currentRate, changePercent);
        if (typeof notifyAlert === 'function') {
          notifyAlert(alert);
        }
      }
    }
  }
}

export function getCurrenciesConfig() {
  return {
    base: BASE_CURRENCY,
    quotes: QUOTE_CURRENCIES,
    thresholdPercent: ALERT_THRESHOLD_PERCENT,
    source: lastSourceMeta
  };
}

export function getDefaultSyncCron() {
  return '*/15 * * * * *';
}
